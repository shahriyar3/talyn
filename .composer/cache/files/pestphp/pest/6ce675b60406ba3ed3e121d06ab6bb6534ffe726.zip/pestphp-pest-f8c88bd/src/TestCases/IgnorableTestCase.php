<?php

declare(strict_types=1);

namespace Pest\TestCases;

use PHPUnit\Framework\TestCase;

/**
 * @internal
 */
final class IgnorableTestCase extends TestCase
{
    // ...
}
